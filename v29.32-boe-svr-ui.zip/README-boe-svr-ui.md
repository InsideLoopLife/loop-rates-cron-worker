# BoE/SVR UI - built to show what's real, not what's hoped for

Two separate deliveries, two separate repos. Don't mix them up - that's bitten us a few times this session.

## loop/ -> goes into Loop (the web app)
```
domains/wealth/house/HousePage.tsx
components/mortgage/MortgagePlannerClient.tsx
```
New "Market benchmarks" section, shown on the Mortgage deals tab, above the deal list:
- Bank Rate, live (currently 3.75%)
- 2-year fixed by LTV tier - shows real rows if present, otherwise says plainly "still populating" rather than showing empty/fake tiers. Right now this will show the honest message, because that data isn't landing yet (see below).
- SVR knowledge centre - all 8 lenders, sorted cheapest to most expensive, HSBC flagged as not tracking Bank Rate rather than implying a spread that isn't real
- "Compare live market rates" link to Moneyfacts, matching the compliance framing from earlier - benchmarks only, no specific product being promoted here

## worker/ -> goes into loop-rates-cron-worker
```
src/boe-benchmarks.mjs
```
Added diagnostics, not a guessed fix. Real data check: only 1 of 15 requested BoE series landed (Bank Rate) - the 5 confirmed 2yr-fixed LTV codes didn't, and `raw_series_title` came back empty even for the series that DID work, meaning the title-parsing logic isn't finding anything in BoE's real response at all.

Rather than guess again, the next cron run's `boeBenchmarks` block will now include a `diagnostics` object showing exactly which series codes BoE's response actually included as columns (`headerColumnsFound`) versus which were requested but never showed up (`requestedButAbsentFromHeader`), plus the first 500 characters of the raw response. That will tell us definitively whether this is a request-side issue (too many series codes in one call, BoE silently dropping some) or something else - rather than me modifying the parser again without evidence.

## Verified
```
Loop:                    npx tsc --noEmit -> exit 0
                          npm run build     -> compiles clean, same one unrelated
                                               env-var failure as every check this session

loop-rates-cron-worker:  node --check src/boe-benchmarks.mjs -> OK
                          npm test -> all 3 existing tests still pass
```

## What to do next
1. Ship both
2. Trigger the cron once
3. Send me the `boeBenchmarks.diagnostics` block from that run's log - that's what actually tells us how to fix the LTV-tier gap for real, instead of another guess
